package com.mohamed.halim.essa.donotforget;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.LoaderManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.CursorAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.mohamed.halim.essa.donotforget.data.TaskContract;
import com.mohamed.halim.essa.donotforget.notification.AlertReceiver;
import com.mohamed.halim.essa.donotforget.notification.NotificationHelper;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements InsertDialog.AddTaskListener , LoaderManager.LoaderCallbacks<Cursor> {
    private final String TAG = MainActivity.class.getSimpleName();
    private final String INSERT_DIALOG_TAG = "insert dialog";
    private ListView mTasksList;
    CursorAdapter mAdapter = new TaskCursorAdapter(this, null);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FloatingActionButton mAddActionButton = findViewById(R.id.fab);
        mTasksList = findViewById(R.id.tasks_list);

        NotificationHelper.createTaskNotificationChannel(this);

        mTasksList.setAdapter(mAdapter);
        getLoaderManager().initLoader(100, null, this);

        mAddActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openInsertDialog();
            }
        });
    }

    private void openInsertDialog() {
        InsertDialog insertDialog = new InsertDialog(this);
        insertDialog.show(getSupportFragmentManager(), INSERT_DIALOG_TAG);
    }

    @Override
    public void addTask(String task,String time) {


        ContentValues values = new ContentValues();

        values.put(TaskContract.TaskEntry.COLUMN_TASK_NAME, task);
        values.put(TaskContract.TaskEntry.COLUMN_TASK_TIME, time);

        getContentResolver().insert(TaskContract.TaskEntry.CONTENT_URI, values);

        setAlarm(task, time);

    }

    private void setAlarm(String task, String time) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        intent.putExtra(TaskContract.TaskEntry.COLUMN_TASK_NAME, task);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        String[] timeSplit = time.split(":");
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, Integer.valueOf(timeSplit[0]));
        c.set(Calendar.MINUTE, Integer.valueOf(timeSplit[1]));
        c.set(Calendar.SECOND, 0);
        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1);
        }
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection = {TaskContract.TaskEntry._ID,
                TaskContract.TaskEntry.COLUMN_TASK_NAME,
                TaskContract.TaskEntry.COLUMN_TASK_TIME};
        return new CursorLoader(this,
                TaskContract.TaskEntry.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
    }
}
