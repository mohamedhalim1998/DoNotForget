package com.mohamed.halim.essa.donotforget;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.mohamed.halim.essa.donotforget.data.TaskContract;

public class TaskCursorAdapter extends CursorAdapter {
    public TaskCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView taskName = view.findViewById(R.id.task_name_tv);
        TextView taskTime = view.findViewById(R.id.task_time_tv);

        int columnNameIndex = cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_TASK_NAME);
        int columnTimeIndex = cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_TASK_TIME);

        String nameValue = cursor.getString(columnNameIndex);
        String timeValue = cursor.getString(columnTimeIndex);

        taskName.setText(nameValue);
        taskTime.setText(timeValue);
    }
}
